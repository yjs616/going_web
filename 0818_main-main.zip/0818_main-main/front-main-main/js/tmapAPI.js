var map, marker1, marker;
var markerArr = [], labelArr = [];
var CCTVLat = [];
var CCTVLon = [];
var lightsLat = [];
var lightsLon = [];
var safeHouseLat = [];
var safeHouseLon = [];

var startX, startY, endX, endY;
var totalMarkerArr=[];
var drawInfoArr=[];
var resultdrawArr=[];
var smokingArea=[[37.59132632,127.0184788],[37.59216991,127.0167352],[37.59262031,127.017374],[37.59285788,127.01924],[37.59176602,127.0183928],[37.58954935,127.0197736]];




// 페이지가 로딩이 된 후 호출하는 함수입니다.
function initTmap(){

    // map 생성
    // Tmapv2.Map을 이용하여, 지도가 들어갈 div, 넓이, 높이를 설정합니다.
    map = new Tmapv2.Map("map_div", { // 지도가 생성될 div
            center : new Tmapv2.LatLng(37.59154, 127.02211), //성신여대
            width : "100%", // 지도의 넓이
            height : "800px", // 지도의 높이
            zoom : 17,
            zoomControl : true,
            scrollwheel : true
    });

    if (navigator.geolocation) { // GPS를 지원하면
        navigator.geolocation.getCurrentPosition(function(position) {
            map.setCenter(new Tmapv2.LatLng(position.coords.latitude, position.coords.longitude));


        }, function(error) {
          console.error(error);
        }, {
          enableHighAccuracy: false,
          maximumAge: 0,
          timeout: Infinity
        });
    }

    marker1 = new Tmapv2.Marker(
    {
        icon : "images/marker.png",
        iconSize : new Tmapv2.Size(24, 24),
        map : map
    });

    //start 찍기
    markerStart = new Tmapv2.Marker(
        {
            icon : "http://tmapapi.sktelecom.com/upload/tmap/marker/pin_r_m_s.png",
            iconSize : new Tmapv2.Size(24,38),
            map : map
        });

    //end 찍기
    markerEnd = new Tmapv2.Marker(
        {
            icon : "http://tmapapi.sktelecom.com/upload/tmap/marker/pin_r_m_e.png",
            iconSize : new Tmapv2.Size(24,38),
            map : map
        });



    /*
    //cctv
    $.ajax({
        url : 'static/CCTV.csv',
        dataType : 'text',
        async : false
    }).done(successFunctionCCTV);

    //CCTV 원 만들기
    for(var c = 0 ; c < CCTVLon.length ; c++){
        var circle = new Tmapv2.Circle({
            center : new Tmapv2.LatLng(CCTVLat[c], CCTVLon[c]),
            radius : 5,
            strokeColor : "#646f9d",
            fillColor : "#646f9d",
            map : map
        });
    }*/


    //cctv 클릭하면 cctv 위치 보여줌(엑셀)
    $("#cctv_select").click(function(){
        
        //cctv
        $.ajax({
            url : 'static/CCTV.csv',
            dataType : 'text',
            async : false
        }).done(successFunctionCCTV);

        //CCTV 원 만들기
        for(var c = 0 ; c < CCTVLon.length ; c++){
            var circle = new Tmapv2.Circle({
                center : new Tmapv2.LatLng(CCTVLat[c], CCTVLon[c]),
                radius : 5,
                strokeColor : "#646f9d",
                fillColor : "#646f9d",
                map : map
            });
        }   
       
    });

    //가로등(엑셀)
    $.ajax({
            url : 'static/lights.csv',
            dataType : 'text',
            async : false
        }).done(successFunctionLights);

        for(var l = 0 ; l < lightsLon.length ; l++){
            var circle = new Tmapv2.Circle({
                center : new Tmapv2.LatLng(lightsLat[l], lightsLon[l]),
                radius : 3,
                strokeColor : "#ECDDA0",
                fillColor : '#ECDDA0',
                map : map
            });
        }

    //여성안심지킴이집(엑셀)
    $.ajax({
            url : 'static/safeHouse.csv',
            dataType : 'text',
            async : false
        }).done(successFunctionSafeHouse);
    
    for(var s = 0 ; s < safeHouseLon.length ; s++){

         var circle = new Tmapv2.Circle({
            center : new Tmapv2.LatLng(safeHouseLat[s], safeHouseLon[s]),
            radius : 5,
            strokeColor : "#FF007F",
            fillColor : "#FF007F",
            map : map
         });
    }

    // 담배스팟 배열로 처리
    for(var c = 0 ; c < smokingArea.length ; c++){
        var circle = new Tmapv2.Circle({
            center : new Tmapv2.LatLng(smokingArea[c][0], smokingArea[c][1]),
            radius : 8,
            strokeColor : "#black",
            fillColor : "black",
            map : map
        });
    }


    map.addListener("click", function onClick(evt){
        var mapLatLng = evt.latLng;

        //기존 마커 삭제
        marker1.setMap(null);

        if(markerArr.length > 0){
            for(var i in markerArr){
                markerArr[i].setMap(null);
            }
            markerArr = [];
        }

        if(labelArr.length > 0){
            for(var i in labelArr){
                labelArr[i].setMap(null);
            }
            labelArr = [];
        }

        // var resultDiv = document.getElementById("result");
        // resultDiv.innerHTML = "";

        $("#searchResult").html("");


        var markerPositionClick = new Tmapv2.LatLng(
            mapLatLng._lat, mapLatLng._lng);

        //마커 올리기
        marker1 = new Tmapv2.Marker(
            {
                position : markerPositionClick,
                icon : "images/marker.png",
                iconSize : new Tmapv2.Size(24, 24),
                map : map
            }
        );

        reverseGeo(mapLatLng._lng, mapLatLng._lat);

        document.getElementById("start").style.display='inline';
        document.getElementById("end").style.display='inline';
    });

    // POI 통합 검색 API 요청
    // full text geocoding
    $("#btn_select1").click(function(){
        var searchKeyword = $('#searchStart').val();
        var fullAddr = $('#searchStart').val();

        $.ajax({
            method:"GET", // 요청 방식
            url:"https://apis.openapi.sk.com/tmap/pois/search/around?version=1&format=json&callback=result", // url 주소
            data:{
                "categories" : searchKeyword,
                "resCoordType" : "EPSG3857",
                "searchType" : "name",
                "searchtypCd" : "A",
                "radius" : 1,
                "reqCoordType" : "WGS84GEO",
                "centerLon" : Number(map.getCenter()._lng),
                "centerLat" : Number(map.getCenter()._lat),
                "appKey" : "l7xxd7c1a7afb16e439fb30e21a831e76dcc",
                "count" : 50
            },
            success:function(response1){
                console.log(response1);

                var resultpoisData = response1.searchPoiInfo.pois.poi;

                // 2. 기존 마커, 팝업 제거
                marker1.setMap(null);

                if(markerArr.length > 0){
                    for(var i in markerArr){
                        markerArr[i].setMap(null);
                    }
                    markerArr = [];
                }

                if(labelArr.length > 0){
                    for(var i in labelArr){
                        labelArr[i].setMap(null);
                    }
                    labelArr = [];
                }

                var resultDiv = document.getElementById("result");
                resultDiv.innerHTML = "";

                var innerHtml = ""; // Search Reulsts 결과값 노출 위한 변수
                var positionBounds = new Tmapv2.LatLngBounds(); //맵에 결과물 확인 하기 위한 LatLngBounds객체 생성

                // 3. POI 마커 표시
                for(var k in resultpoisData){
                    // POI 마커 정보 저장
                    var noorLat = Number(resultpoisData[k].noorLat);
                    var noorLon = Number(resultpoisData[k].noorLon);
                    var name = resultpoisData[k].name;
                    var telNo = resultpoisData[k].telNo;

                    // POI 정보의 ID
                    var id = resultpoisData[k].id;

                    // 좌표 객체 생성
                    var pointCng = new Tmapv2.Point(noorLon, noorLat);

                    // EPSG3857좌표계를 WGS84GEO좌표계로 변환
                    var projectionCng = new Tmapv2.Projection.convertEPSG3857ToWGS84GEO(pointCng);

                    var lat = projectionCng._lat;
                    var lon = projectionCng._lng;

                    // 좌표 설정
                    var markerPosition = new Tmapv2.LatLng(lat, lon);

                    // Marker 설정
                    marker = new Tmapv2.Marker({
                        // id : id,
                        position : markerPosition,
                        icon : "images/marker.png",
                        iconSize : new Tmapv2.Size(24, 24),
                        title : name,
                        map:map,
                    });

                    // 결과창에 나타날 검색 결과 html
                    innerHtml += "<li><div><span>"+name+"&nbsp;"+"&nbsp;"+telNo+"</span>"+"&nbsp;"+"&nbsp"+"<button type='button' name='sendBtn' onClick='poiDetail("+id+");'>주소보기</button>"+"</div></li>";

                    // 마커들을 담을 배열에 마커 저장
                    markerArr.push(marker);
                    positionBounds.extend(markerPosition);   // LatLngBounds의 객체 확장

                    // marker.addListener("click", function(evt,id) {
                    //     //
                    // });
                }

                $("#searchResult").html(innerHtml);   //searchResult 결과값 노출

                map.panToBounds(positionBounds);   // 확장된 bounds의 중심으로 이동시키기
                map.zoomIn();

            },
        error:function(request,status,error){
            console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
            }
        });

        $.ajax({
            method : "GET",
            url : "https://apis.openapi.sk.com/tmap/geo/fullAddrGeo?version=1&format=json&callback=result",
            async : false,
            data : {
                "appKey" : "l7xxd7c1a7afb16e439fb30e21a831e76dcc",
                "coordType" : "WGS84GEO",
                "fullAddr" : fullAddr
            },
            success : function(response1) {
                var resultInfo = response1.coordinateInfo; // .coordinate[0];
                console.log(resultInfo);

                // 기존 마커 삭제
                marker1.setMap(null);

                // if(markerArr.length > 0){
                //     for(var i in markerArr){
                //         markerArr[i].setMap(null);
                //     }
                //     markerArr = [];
                // }

                // if(labelArr.length > 0){
                //     for(var i in labelArr){
                //         labelArr[i].setMap(null);
                //     }
                //     labelArr = [];
                // }

                // var resultDiv = document.getElementById("result");
                // resultDiv.innerHTML = "";

                // $("#searchResult").html("");   //searchResult 결과값 노출


                // 3.마커 찍기
                // 검색 결과 정보가 없을 때 처리
                if (resultInfo.coordinate.length == 0) {
                    $("#result").text(
                    "요청 데이터가 올바르지 않습니다.");
                } else {
                    var lon, lat;
                    var resultCoordinate = resultInfo.coordinate[0];
                    if (resultCoordinate.lon.length > 0) {
                        // 구주소
                        lon = resultCoordinate.lon;
                        lat = resultCoordinate.lat;
                    } else {
                        // 신주소
                        lon = resultCoordinate.newLon;
                        lat = resultCoordinate.newLat
                    }

                    var lonEntr, latEntr;

                    if (resultCoordinate.lonEntr == undefined && resultCoordinate.newLonEntr == undefined) {
                        lonEntr = 0;
                        latEntr = 0;
                    } else {
                        if (resultCoordinate.lonEntr.length > 0) {
                            lonEntr = resultCoordinate.lonEntr;
                            latEntr = resultCoordinate.latEntr;
                        } else {
                            lonEntr = resultCoordinate.newLonEntr;
                            latEntr = resultCoordinate.newLatEntr;
                        }
                    }

                    var markerPosition = new Tmapv2.LatLng(Number(lat),Number(lon));

                    //마커 올리기
                    marker1 = new Tmapv2.Marker({
                        position : markerPosition,
                        icon : "images/marker.png",
                        iconSize : new Tmapv2.Size(24,24),
                        map : map
                    });

                    map.setCenter(markerPosition);

                }
            },

            error : function(request, status, error) {
                console.log(request);
                console.log("code:"+request.status + "\n message:" + request.responseText +"\n error:" + error);
                // 에러가 발생하면 맵을 초기화함
                // markerStartLayer.clearMarkers();
                // 마커초기화
                map.setCenter(new Tmapv2.LatLng(37.59154, 127.02211));
                $("#result").html("");

            }
        });
    });

    $("#btn_select2").click(function(){
        var searchKeyword = $('#searchEnd').val();
        var fullAddr = $('#searchEnd').val();

        $.ajax({
            method:"GET", // 요청 방식
            url:"https://apis.openapi.sk.com/tmap/pois/search/around?version=1&format=json&callback=result", // url 주소
            data:{
                "categories" : searchKeyword,
                "resCoordType" : "EPSG3857",
                "searchType" : "name",
                "searchtypCd" : "A",
                "radius" : 1,
                "reqCoordType" : "WGS84GEO",
                "centerLon" : Number(map.getCenter()._lng),
                "centerLat" : Number(map.getCenter()._lat),
                "appKey" : "l7xxd7c1a7afb16e439fb30e21a831e76dcc",
                "count" : 50
            },
            success:function(response2){
                console.log(response2);

                var resultpoisData = response2.searchPoiInfo.pois.poi;

                // 2. 기존 마커, 팝업 제거
                marker1.setMap(null);

                if(markerArr.length > 0){
                    for(var i in markerArr){
                        markerArr[i].setMap(null);
                    }
                    markerArr = [];
                }

                if(labelArr.length > 0){
                    for(var i in labelArr){
                        labelArr[i].setMap(null);
                    }
                    labelArr = [];
                }

                var resultDiv = document.getElementById("result");
                resultDiv.innerHTML = "";

                var innerHtml = ""; // Search Reulsts 결과값 노출 위한 변수
                var positionBounds = new Tmapv2.LatLngBounds(); //맵에 결과물 확인 하기 위한 LatLngBounds객체 생성

                // 3. POI 마커 표시
                for(var k in resultpoisData){
                    // POI 마커 정보 저장
                    var noorLat = Number(resultpoisData[k].noorLat);
                    var noorLon = Number(resultpoisData[k].noorLon);
                    var name = resultpoisData[k].name;
                    var telNo = resultpoisData[k].telNo;

                    // POI 정보의 ID
                    var id = resultpoisData[k].id;

                    // 좌표 객체 생성
                    var pointCng = new Tmapv2.Point(noorLon, noorLat);

                    // EPSG3857좌표계를 WGS84GEO좌표계로 변환
                    var projectionCng = new Tmapv2.Projection.convertEPSG3857ToWGS84GEO(pointCng);

                    var lat = projectionCng._lat;
                    var lon = projectionCng._lng;

                    // 좌표 설정
                    var markerPosition = new Tmapv2.LatLng(lat, lon);

                    // Marker 설정
                    marker = new Tmapv2.Marker({
                        position : markerPosition,
                        icon : "images/marker.png",
                        iconSize : new Tmapv2.Size(24, 24),
                        title : name,
                        map : map
                    });

                    // 결과창에 나타날 검색 결과 html
                    innerHtml += "<li><div><span>"+name+"&nbsp;"+"&nbsp;"+telNo+"</span>"+"&nbsp;"+"&nbsp"+"<button type='button' name='sendBtn' onClick='poiDetail("+id+");'>주소보기</button>"+"</div></li>";


                    // 마커들을 담을 배열에 마커 저장
                    markerArr.push(marker);
                    positionBounds.extend(markerPosition);	// LatLngBounds의 객체 확장

                }

                $("#searchResult").html(innerHtml);	//searchResult 결과값 노출

                map.panToBounds(positionBounds);	// 확장된 bounds의 중심으로 이동시키기
                map.zoomIn();

            },
            error:function(request,status,error){
                console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
            }
        });

        $.ajax({
            method : "GET",
            url : "https://apis.openapi.sk.com/tmap/geo/fullAddrGeo?version=1&format=json&callback=result",
            async : false,
            data : {
                "appKey" : "l7xxd7c1a7afb16e439fb30e21a831e76dcc",
                "coordType" : "WGS84GEO",
                "fullAddr" : fullAddr
            },
            success : function(response2) {
                var resultInfo = response2.coordinateInfo; // .coordinate[0];
                console.log(resultInfo);

                // 기존 마커 삭제
                marker1.setMap(null);

                // 3.마커 찍기
                // 검색 결과 정보가 없을 때 처리
                if (resultInfo.coordinate.length == 0) {
                    $("#result").text(
                    "요청 데이터가 올바르지 않습니다.");
                } else {
                    var lon, lat;
                    var resultCoordinate = resultInfo.coordinate[0];
                    if (resultCoordinate.lon.length > 0) {
                        // 구주소
                        lon = resultCoordinate.lon;
                        lat = resultCoordinate.lat;
                    } else {
                        // 신주소
                        lon = resultCoordinate.newLon;
                        lat = resultCoordinate.newLat
                    }

                    var lonEntr, latEntr;

                    if (resultCoordinate.lonEntr == undefined && resultCoordinate.newLonEntr == undefined) {
                        lonEntr = 0;
                        latEntr = 0;
                    } else {
                        if (resultCoordinate.lonEntr.length > 0) {
                            lonEntr = resultCoordinate.lonEntr;
                            latEntr = resultCoordinate.latEntr;
                        } else {
                            lonEntr = resultCoordinate.newLonEntr;
                            latEntr = resultCoordinate.newLatEntr;
                        }
                    }

                    var markerPosition = new Tmapv2.LatLng(Number(lat),Number(lon));

                    // 마커 올리기
                    marker1 = new Tmapv2.Marker({
                        position : markerPosition,
                        icon : "images/marker.png",
                        iconSize : new Tmapv2.Size(
                        24, 24),
                        map : map
                    });
                    map.setCenter(markerPosition);
                }
            },
            error : function(request, status, error) {
                console.log(request);
                console.log("code:"+request.status + "\n message:" + request.responseText +"\n error:" + error);
                // 에러가 발생하면 맵을 초기화함
                // markerStartLayer.clearMarkers();
                // 마커초기화
                map.setCenter(new Tmapv2.LatLng(37.570028, 126.986072));
                $("#result").html("");

            }
        });

    });

    var startButton = document.getElementById("start");
    startButton.addEventListener("click", function start(evt){
        var fullAddr = document.getElementById("result").innerHTML;
        $.ajax({
            method : "POST",
            url : "https://apis.openapi.sk.com/tmap/geo/fullAddrGeo?version=1&format=json&callback=result",
            data : {
                "appKey" : "l7xxd7c1a7afb16e439fb30e21a831e76dcc",
                "coordType" : "WGS84GEO",
                "fullAddr" : fullAddr
            },
            success : function(response) {
                var resultInfo = response.coordinateInfo; // .coordinate[0];
                console.log(resultInfo);

                // 기존 마커 삭제
                if (resultdrawArr.length > 0) {
                    for ( var i in resultdrawArr) {
                        resultdrawArr[i].setMap(null);
                    }
                    resultdrawArr = [];
                }

                marker1.setMap(null);

                if(markerArr.length > 0){
                    for(var i in markerArr){
                        markerArr[i].setMap(null);
                    }
                }
                drawInfoArr = [];

                if(markerStart!=null){
                    markerStart.setMap(null);
                }

                // 3.마커 찍기
                // 검색 결과 정보가 없을 때 처리
                if (resultInfo.coordinate.length == 0) {
                    $("#result").text(
                    "요청 데이터가 올바르지 않습니다.");
                } else {
                    var lon, lat;
                    var resultCoordinate = resultInfo.coordinate[0];
                    if (resultCoordinate.lon.length > 0) {
                        // 구주소
                        lon = resultCoordinate.lon;
                        lat = resultCoordinate.lat;
                    } else {
                        // 신주소
                        lon = resultCoordinate.newLon;
                        lat = resultCoordinate.newLat
                    }

                    var lonEntr, latEntr;

                    if (resultCoordinate.lonEntr == undefined && resultCoordinate.newLonEntr == undefined) {
                        lonEntr = 0;
                        latEntr = 0;
                    } else {
                        if (resultCoordinate.lonEntr.length > 0) {
                            lonEntr = resultCoordinate.lonEntr;
                            latEntr = resultCoordinate.latEntr;
                        } else {
                            lonEntr = resultCoordinate.newLonEntr;
                            latEntr = resultCoordinate.newLatEntr;
                        }
                    }

                    var markerPosition = new Tmapv2.LatLng(Number(lat),Number(lon));

                    // 마커 올리기
                    markerStart = new Tmapv2.Marker({
                        position : markerPosition,
                        icon : "images/sujeong.png",
                        iconSize : new Tmapv2.Size(36, 36),
                        map : map
                    });
                    map.setCenter(markerPosition);
                    startX = markerPosition._lng;
                    startY = markerPosition._lat;

                    $("#searchStart").val(fullAddr);
                }
            },
            error : function(request, status, error) {
                console.log(request);
                console.log("code:"+request.status + "\n message:" + request.responseText +"\n error:" + error);
                // 에러가 발생하면 맵을 초기화함
                // markerStartLayer.clearMarkers();
                // 마커초기화
                map.setCenter(new Tmapv2.LatLng(37.570028, 126.986072));
                $("#result").html("");

            }
        });
    });


    var endButton = document.getElementById("end");
    endButton.addEventListener("click", function end(evt){
        var fullAddr = document.getElementById("result").innerHTML;
        $.ajax({
            method : "POST",
            url : "https://apis.openapi.sk.com/tmap/geo/fullAddrGeo?version=1&format=json&callback=result",
            data : {
                "appKey" : "l7xxd7c1a7afb16e439fb30e21a831e76dcc",
                "coordType" : "WGS84GEO",
                "fullAddr" : fullAddr
            },
            success : function(response) {
                var resultInfo = response.coordinateInfo; // .coordinate[0];
                console.log(resultInfo);

                // 기존 마커 삭제
                marker1.setMap(null);

                if(markerEnd!=null){
                    markerEnd.setMap(null);
                }

                if (resultdrawArr.length > 0) {
                    for ( var i in resultdrawArr) {
                        resultdrawArr[i].setMap(null);
                    }
                    resultdrawArr = [];
                }

                if(markerArr.length > 0){
                    for(var i in markerArr){
                        markerArr[i].setMap(null);
                    }
                }
                drawInfoArr = [];

                // 3.마커 찍기
                // 검색 결과 정보가 없을 때 처리
                if (resultInfo.coordinate.length == 0) {
                    $("#result").text(
                    "요청 데이터가 올바르지 않습니다.");
                } else {
                    var lon, lat;
                    var resultCoordinate = resultInfo.coordinate[0];
                    if (resultCoordinate.lon.length > 0) {
                        // 구주소
                        lon = resultCoordinate.lon;
                        lat = resultCoordinate.lat;
                    } else {
                        // 신주소
                        lon = resultCoordinate.newLon;
                        lat = resultCoordinate.newLat
                    }

                    var lonEntr, latEntr;

                    if (resultCoordinate.lonEntr == undefined && resultCoordinate.newLonEntr == undefined) {
                        lonEntr = 0;
                        latEntr = 0;
                    } else {
                        if (resultCoordinate.lonEntr.length > 0) {
                            lonEntr = resultCoordinate.lonEntr;
                            latEntr = resultCoordinate.latEntr;
                        } else {
                            lonEntr = resultCoordinate.newLonEntr;
                            latEntr = resultCoordinate.newLatEntr;
                        }
                    }

                    var markerPosition = new Tmapv2.LatLng(Number(lat),Number(lon));

                    // 마커 올리기
                    markerEnd = new Tmapv2.Marker({
                        position : markerPosition,
                        icon : "images/ball.png",
                        iconSize : new Tmapv2.Size(24, 24),
                        map : map
                    });
                    map.setCenter(markerPosition);
                    endX = markerPosition._lng;
                    endY = markerPosition._lat;

                    $("#searchEnd").val(fullAddr);
                }
            },
            error : function(request, status, error) {
                console.log(request);
                console.log("code:"+request.status + "\n message:" + request.responseText +"\n error:" + error);
                // 에러가 발생하면 맵을 초기화함
                // markerStartLayer.clearMarkers();
                // 마커초기화
                map.setCenter(new Tmapv2.LatLng(37.570028, 126.986072));
                $("#result").html("");

            }
        });
    });


    var searchRoute = document.getElementById("searchRoute");

    searchRoute.addEventListener("click", function route(evt){



        $.ajax({
            method : "POST",
            url : "https://apis.openapi.sk.com/tmap/routes/pedestrian?version=1&format=json&callback=result",
            async : false,
            data : {
                "appKey" : "l7xxd7c1a7afb16e439fb30e21a831e76dcc",
                "startX" : startX,
                "startY" : startY,
                "endX" : endX,
                "endY" : endY,
                "reqCoordType" : "WGS84GEO",
                "resCoordType" : "EPSG3857",
                "startName" : "출발지",
                "endName" : "도착지",

            },
            success : function(response) {
                var resultData = response.features;

                var tDistance = "거리 : "
                        + ((resultData[0].properties.totalDistance) / 1000)
                                .toFixed(1) + "km,";
                var tTime = "시간 : "
                        + ((resultData[0].properties.totalTime) / 60)
                                .toFixed(0) + "분";

                $("#result").text(tDistance + tTime);

                //기존 그려진 라인 & 마커가 있다면 초기화
                if (resultdrawArr.length > 0) {
                    for ( var i in resultdrawArr) {
                        resultdrawArr[i].setMap(null);
                    }
                    resultdrawArr = [];
                }

                marker1.setMap(null);

                if(markerArr.length > 0){
                    for(var i in markerArr){
                        markerArr[i].setMap(null);
                    }
                }
                drawInfoArr = [];


                for ( var i in resultData) { //for문 [S]
                    var geometry = resultData[i].geometry;
                    var properties = resultData[i].properties;
                    var polyline_;


                    if (geometry.type == "LineString") {
                        for ( var j in geometry.coordinates) {
                            // 경로들의 결과값(구간)들을 포인트 객체로 변환
                            var latlng = new Tmapv2.Point(
                                    geometry.coordinates[j][0],
                                    geometry.coordinates[j][1]);
                            // 포인트 객체를 받아 좌표값으로 변환
                            var convertPoint = new Tmapv2.Projection.convertEPSG3857ToWGS84GEO(
                                    latlng);
                            // 포인트객체의 정보로 좌표값 변환 객체로 저장
                            var convertChange = new Tmapv2.LatLng(
                                    convertPoint._lat,
                                    convertPoint._lng);
                            // 배열에 담기
                            drawInfoArr.push(convertChange);
                        }
                    } else {
                        var markerImg = "";
                        var pType = "";
                        var size;

                        if (properties.pointType == "S") { //출발지 마커
                            markerImg = "images/sujeong.png";
                            pType = "S";
                            size = new Tmapv2.Size(24, 24);
                        } else if (properties.pointType == "E") { //도착지 마커
                            markerImg = "images/ball.png";
                            pType = "E";
                            size = new Tmapv2.Size(24, 24);
                        } else { //각 포인트 마커
                            markerImg = "http://topopen.tmap.co.kr/imgs/point.png";
                            pType = "P";
                            size = new Tmapv2.Size(8, 8);
                        }

                        // 경로들의 결과값들을 포인트 객체로 변환
                        var latlon = new Tmapv2.Point(
                                geometry.coordinates[0],
                                geometry.coordinates[1]);

                        // 포인트 객체를 받아 좌표값으로 다시 변환
                        var convertPoint = new Tmapv2.Projection.convertEPSG3857ToWGS84GEO(
                                latlon);

                        var routeInfoObj = {
                            markerImage : markerImg,
                            lng : convertPoint._lng,
                            lat : convertPoint._lat,
                            pointType : pType
                        };

                        // Marker 추가
                        marker_p = new Tmapv2.Marker(
                        {
                            position : new Tmapv2.LatLng(
                                    routeInfoObj.lat,
                                    routeInfoObj.lng),
                            icon : routeInfoObj.markerImage,
                            iconSize : size,
                            map : map
                        });

                        markerArr.push(marker_p);

                    }
                }//for문 [E]
                drawLine(drawInfoArr);
                map.setCenter(new Tmapv2.LatLng((startY+endY)/2, (startX+endX)/2));
            },
            error : function(request, status, error) {
                console.log("code:" + request.status + "\n"
                        + "message:" + request.responseText + "\n"
                        + "error:" + error);
            }
        });

    });
}

function drawLine(arrPoint) {
    var polyline_;

    polyline_ = new Tmapv2.Polyline({
        path : arrPoint,
        strokeColor : "#646F9D",
        strokeWeight : 6,
        map : map
    });
    resultdrawArr.push(polyline_);
}





function reverseGeo(lon, lat) {
    $.ajax({
        method : "GET",
        url : "https://apis.openapi.sk.com/tmap/geo/reversegeocoding?version=1&format=json&callback=result",
        async : false,
        data : {
            "appKey" : "l7xxd7c1a7afb16e439fb30e21a831e76dcc",
            "coordType" : "WGS84GEO",
            "addressType" : "A10",
            "lon" : lon,
            "lat" : lat
        },
        success : function(response) {
            // 3. json에서 주소 파싱
            var arrResult = response.addressInfo;

            //법정동 마지막 문자
            var lastLegal = arrResult.legalDong
                    .charAt(arrResult.legalDong.length - 1);

            // 새주소
            newRoadAddr = arrResult.city_do + ' '
                    + arrResult.gu_gun + ' ';

            if (arrResult.eup_myun == ''
                    && (lastLegal == "읍" || lastLegal == "면")) {//읍면
                newRoadAddr += arrResult.legalDong;
            } else {
                newRoadAddr += arrResult.eup_myun;
            }
            newRoadAddr += ' ' + arrResult.roadName + ' '
                    + arrResult.buildingIndex;

            // 새주소 법정동& 건물명 체크
            if (arrResult.legalDong != ''
                    && (lastLegal != "읍" && lastLegal != "면")) {//법정동과 읍면이 같은 경우

                if (arrResult.buildingName != '') {//빌딩명 존재하는 경우
                    newRoadAddr += (' (' + arrResult.legalDong
                            + ', ' + arrResult.buildingName + ') ');
                } else {
                    newRoadAddr += (' (' + arrResult.legalDong + ')');
                }
            } else if (arrResult.buildingName != '') {//빌딩명만 존재하는 경우
                newRoadAddr += (' (' + arrResult.buildingName + ') ');
            }

            result = newRoadAddr ;

            var resultDiv = document.getElementById("result");
            resultDiv.innerHTML = result;

        },
        error : function(request, status, error) {
            console.log("code:" + request.status + "\n"
                    + "message:" + request.responseText + "\n"
                    + "error:" + error);
        }
    });
};

function successFunctionCCTV(data){
    var allRows = data.split('\n');
    for (var singleRow = 1 ; singleRow<allRows.length; singleRow++){
        var rowCells = allRows[singleRow].split(',');
        CCTVLat.push(rowCells[3]);
        CCTVLon.push(rowCells[4]);
    }
}

function successFunctionLights(data){
    var allRows = data.split('\n');
    for (var singleRow = 1 ; singleRow<allRows.length; singleRow++){
        var rowCells = allRows[singleRow].split(',');
        lightsLat.push(rowCells[4]);
        lightsLon.push(rowCells[5]);
    }
}

function successFunctionSafeHouse(data){
    var allRows = data.split('\n');
    for (var singleRow = 1 ; singleRow<allRows.length; singleRow++){
        var rowCells = allRows[singleRow].split(',');
        safeHouseLat.push(rowCells[6]);     //위도
        safeHouseLon.push(rowCells[7]);     //경도
    }
}

function poiDetail(poiId){
    $.ajax({
        method:"GET",
        url:"	https://apis.openapi.sk.com/tmap/pois/"+poiId+"?version=1&resCoordType=EPSG3857&format=json&callback=result&appKey="+"l7xxd7c1a7afb16e439fb30e21a831e76dcc",
        async:false,
        success:function(response){
            var detailInfo = response.poiDetailInfo;
            var name = detailInfo.name;
            var address = detailInfo.address;
            var addressDetail1 = detailInfo.firstNo;
            var addressDetail2 = detailInfo.secondNo;

            var noorLat = Number(detailInfo.frontLat);
            var noorLon = Number(detailInfo.frontLon);

            var pointCng = new Tmapv2.Point(noorLon, noorLat);
            var projectionCng = new Tmapv2.Projection.convertEPSG3857ToWGS84GEO(pointCng);

            var lat = projectionCng._lat;
            var lon = projectionCng._lng;

            var resultDiv = document.getElementById("result");
            if(addressDetail2!=""){
                resultDiv.innerHTML = address + addressDetail1 +"-"+ addressDetail2;
            }
            else{
                resultDiv.innerHTML = address + addressDetail1;
            }

            document.getElementById("start").style.display='inline';
            document.getElementById("end").style.display='inline';
          },
        error:function(request,status,error){
            console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
        }
    });
}



