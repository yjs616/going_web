//유저가 값을 입력한다
//+를 버튼을 클릭하면 할 일이 추가된다      -> 버튼을 들고와서 클릭이벤트를 줌
//delete 버튼을 누르면 할 일이 삭제된다
//check 버튼을 누르면 할 일이 끝나면서 밑줄이 간다
//진행중 끝남 탭을 누르면, 언더바가 이동한다
//끝남탭은, 끝난 아이템만, 진행중인 탭은 진행중인 아이템만
//전체탭을 누르면 다시 전체 아이템으로 돌아옴.


//document에서 id를 들고 와주세요
let taskInput = document.getElementById("task-input");
let addButton = document.getElementById("add-button");

//button에 이벤트를 주고싶을 때 함수 ("이벤트" , funtion)
addButton.addEventListener("click",addTask);

function addTask(){
    
}
